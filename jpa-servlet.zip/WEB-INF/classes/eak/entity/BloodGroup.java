package eak.entity;

  public enum BloodGroup { A, B, AB, Zero };
