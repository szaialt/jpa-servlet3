package eak;

public class StorageException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -798894509284694758L;}
